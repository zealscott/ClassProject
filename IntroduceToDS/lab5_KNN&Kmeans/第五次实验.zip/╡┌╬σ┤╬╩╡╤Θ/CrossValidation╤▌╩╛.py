import random

from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression


def get_acc(predict,target):
    totle = len(predict)
    trueCount = 0
    for i in range(totle):
        if predict[i] == target[i]:
            trueCount += 1
    return  float(trueCount) / float(totle)

iris = load_iris()


#30个测试数据， 其余验证数据+训练数据

indexList = list(range(0,iris.data.shape[0]))
random.seed(1)
random.shuffle(indexList)

testIndex = indexList[-30:]
trainIndex = indexList[:-30]


#构造数据
data = iris.data
label = iris.target


tvData = data[trainIndex]
tvLabel = label[trainIndex]

testData = data[testIndex]
testLabel = label[testIndex]

#交叉验证
from sklearn.model_selection import StratifiedKFold
skf = StratifiedKFold(n_splits=10)

tvACCList = []


accList = []
clr = LogisticRegression()
for train,validation in skf.split(tvData,tvLabel):

    clr.fit(tvData[train],tvLabel[train])
    labelPredict = clr.predict(tvData[validation])
    accList.append(get_acc(labelPredict,tvLabel[validation]))

averangeACC = sum(accList) / len(accList)
print("10折交叉验证准确率：" + str(averangeACC))
clr.fit(tvData,tvLabel)
testPredict = clr.predict(testData)
testACC = get_acc(testPredict,testLabel)
print("测试集准确率：" + str(testACC))
