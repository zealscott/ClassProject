
public interface HelloService{

    public String hello(String name);

}